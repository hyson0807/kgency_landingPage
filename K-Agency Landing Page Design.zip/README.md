
  # K-Agency Landing Page Design

  This is a code bundle for K-Agency Landing Page Design. The original project is available at https://www.figma.com/design/AWzDufQI3qKsL41DBydjqn/K-Agency-Landing-Page-Design.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  